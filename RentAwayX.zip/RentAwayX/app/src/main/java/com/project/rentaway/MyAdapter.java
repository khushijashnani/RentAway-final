package com.project.rentaway;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private ArrayList<Property>  list = new ArrayList<>();

    public MyAdapter(ArrayList<Property> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Log.d("MyAdapter", "onBindViewHolder: called..");
        Property currentItem = list.get(position);
        holder.address.setText(currentItem.getAdd());
        holder.rent.setText(currentItem.getRent());
        holder.room.setText(currentItem.getBhk());
        holder.imageView.setImageResource(currentItem.getImage());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView address,room,rent;
        public ImageView imageView;

        public MyViewHolder(View itemView) {
            super(itemView);
            address = itemView.findViewById(R.id.place);  //address
            room = itemView.findViewById(R.id.bhk);      //room
            rent = itemView.findViewById(R.id.price);   //rent
            imageView = itemView.findViewById(R.id.card_image);
        }
    }
}
