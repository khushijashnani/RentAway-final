package com.project.rentaway;

public class User {
    private String id;
    private String email;
    private String userName;
    private String password;
    private String phone;
    public User(){

    }
    public User(String id, String email, String userName, String password, String phone) {
        this.id = id;
        this.email = email;
        this.userName = userName;
        this.password = password;
        this.phone = phone;
    }

    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getPhone() {
        return phone;
    }
}
