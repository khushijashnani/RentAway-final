package com.project.rentaway;

import android.widget.ImageView;

public class Property {
    private String Rent;
    private String bhk;
    private String Add;
    private int image;

    public Property(String rent, String bhk, String add, int image) {
        Rent = rent;
        this.bhk = bhk;
        Add = add;
        this.image = image;
    }

    public String getRent() {
        return Rent;
    }

    public String getBhk() {
        return bhk;
    }

    public String getAdd() {
        return Add;
    }

    public int getImage() {
        return image;
    }
}
